PurgeHunter ready-to-build project for Paper 1.21.10.

Android/Termux:
1. Install Java 21 and Gradle.
2. Open this project folder.
3. Run: gradle build
4. JAR output: build/libs/PurgeHunter-1.0.0.jar
5. Put the JAR in the Paper server plugins folder and restart.

Mechanic:
- Player A kills Player B: Purge starts and A is the hunter.
- Purge ends when the active hunter dies.
